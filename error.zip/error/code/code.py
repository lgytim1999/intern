import re
import json
import random
import urllib
import hashlib
import logging
import requests
import numpy as np
import pandas as pd
from os import listdir
from collections import Counter
from time import time, strftime

# configuration files info
CONFIG_FOLDER = 'config/'
AREA_CONFIG = CONFIG_FOLDER + 'area.json'
FACT_CONFIG = CONFIG_FOLDER + 'fact.json'
DIM_CONFIG = CONFIG_FOLDER + 'dim.json'
OUTPUT_CONFIG = CONFIG_FOLDER + 'output.json'

# params info
DIFF_THRESHOLD = 50
PROXY = {
    "http":"http://10.141.110.75:8080"
}

# config for log


pd.set_option('mode.chained_assignment', None)

# global var
df_all = pd.DataFrame()


def shpt_filter(df, threshold):

    df_std = df[df['Description'] == 'Standard Freight']
    col_diff = (df_std['LSP Net Value'] - df_std['Net value']).abs()
    df_std.insert(df_std.shape[1], 'diff', col_diff)
    lst = np.array(df_std[df_std['diff'] >= threshold]
                   ['Shipment Number']).tolist()
    return lst


def shpt_vld(lst_in, lst_not_in):

    print('\tValidation for shpt_num...')

    lst_mis = np.setdiff1d(lst_in, lst_not_in)
    if len(lst_mis) > 0:

        with open(config_output['mis_shpt']['file'], 'w') as f:
            for line in lst_mis:
                f.write(line + '\n')
        

        print('\t\tMissing shpt_num found...')


def is_all_cn(string):
    return not any(u'\u4e00' <= ch <= u'\u9fff' for ch in string)


def to_cn(cities):
    
    # baidu fanyi api
    app_id = '20210205000691269'
    p_key = 'frCEhfVHsg6ssi5GGJHe'

    q = '\n'.join(cities)
    salt = random.randint(32768, 65536)
    sign = app_id + q + str(salt) + p_key
    sign = hashlib.md5(sign.encode()).hexdigest()
    url = 'http://api.fanyi.baidu.com/api/trans/vip/translate?appid={}&q={}&from=en&to=zh&salt={}&sign={}'.format(app_id, urllib.parse.quote(q), salt, sign)
    response = requests.get(url, proxies=PROXY)
    trans_result = response.json()['trans_result']

    return [dic['dst'] for dic in trans_result]


def get_parents(cities):
    
    key = 'dbf80c315fc11dd85b67e5ea8446271f'
    url = 'http://restapi.amap.com/v3/place/text?parameters'
    lst_parent = []
    for city in cities:
        params = {
            'key': key,
            'keywords': city,
            'types': 190100,
            'city': city,
            'citylimit': True,    
            'offset': 10
        }

        r = requests.get(url, params=params, proxies=PROXY)
        data = r.json()['pois']
        t_code = min([int(dic['typecode']) for dic in data if '|' not in dic['typecode']])
        parents = [str({'p': dic['pname'][:2],
                        'c': dic['cityname'][:2]})
                            for dic in data if dic['typecode'] == str(t_code)]
        parent = eval(Counter(parents).most_common(1)[0][0])
        parent['a_is_p'] = city == parent['p']
        parent['a_is_c'] = False if parent['a_is_p'] else (city == parent['c'])
        lst_parent.append(parent)
    return lst_parent


# get lsp & route based on city
def get_lsp_rt(df_fac):

    # load dictionary for area
    with open (AREA_CONFIG, 'rb') as f:
        dic_area = json.loads(f.read())
    
    # check if update is needed
    col_area = df_fac['area'].map(lambda x: re.sub('\s+', '', x))
    lst_area = list(dic_area.keys())
    lst_mis_area = list(np.unique(np.setdiff1d(col_area.tolist(), lst_area)))
    #print(lst_mis_area)
    # update is needed
    if len(lst_mis_area) > 0:

    #    convert pinyin to cn
        lst_mis_area_cn = to_cn(lst_mis_area)
        
    #     # get parent info
        lst_mis_area_par = get_parents(lst_mis_area_cn)
        
        # update dict
        dic_mis = {lst_mis_area[i]: {
                        'cn': lst_mis_area_cn[i],
                        'parent': lst_mis_area_par[i]} 
                    for i in range(len(lst_mis_area))}
        dic_area = dic_area | dic_mis
        with open(AREA_CONFIG, 'w', encoding='utf8') as f:
            json.dump(dic_area, f, ensure_ascii=False)

    # generate area_cn column for original dataframe
    df_fac.loc[:, 'area'] = col_area
    col_cn_area = df_fac['area'].map(lambda x: dic_area[x]['cn'], na_action='ignore')
    df_fac.insert(df_fac.shape[1] - 1, 'area_cn', col_cn_area)
    #print(df_fac)
    # import dim table of TPL
    df_dim_tpl = pd.read_excel(config_dim['tpl']['file'],
                               sheet_name=config_dim['tpl']['sheet'],
                               dtype={'Shpt_Type': str,
                                      'Shpt_Grp':str,
                                      'DG': str,
                                      'Fwd_Agent': str}
                               ).dropna(how='all')

    lst_lsp = []
    lst_rt = []
    for index, row in df_fac.iterrows():


        lsps, rts = [], []

        # basic filter
        df_filter = df_dim_tpl[(df_dim_tpl['TPP'] == row['tpp']) &
                    (df_dim_tpl['Shpt_Type'] == row['shpt_type']) &
                    (df_dim_tpl['Shpt_Grp'] == row['shpt_grp']) &
                    (df_dim_tpl['DG'] != ('1' if row['dg'] == 0 else '0'))]


            
        #print(df_filter)
        if len(df_filter) == 0:
            print(' no data ')

        if len(df_filter) == 1:
            

            if '全国' in df_filter['Province']:

                lsps = df_filter['Fwd_Agent'].values
                rts = df_filter['Shpt_Rt'].values

            else:
                print('no data')
        
        if len(df_filter) > 1:
            #print(row['area_cn'])
            area_cn = row['area_cn']
            parent = dic_area[row['area']]['parent']
            #print(parent)
            #address is detailed to county
            if not (parent['a_is_p'] | parent['a_is_c']):
                df_tmp = df_filter[~df_filter['Area'].isna() &
                                    df_filter['Area'].str.contains(area_cn)]

                if len(df_tmp) == 0:
                    lsps, rts = seek_from_city(df_filter, parent)
                
                else:
                    lsps = df_tmp['Fwd_Agent'].values
                    rts = df_tmp['Shpt_Rt'].values

            #  city
            if parent['a_is_c']:
                
                lsps, rts = seek_from_city(df_filter, parent)
            
            # the original 'area' is a province
            if parent['a_is_p']:
                lsps, rts = seek_in_prov(df_filter, area_cn)
        lst_lsp.append(lsps[0] if len(lsps) == 1 else lsps)
        lst_rt.append(rts[0] if len(rts) == 1 else rts)

    return lst_lsp, lst_rt


# match city column
def seek_from_city(df, parent):
    df_tmp = df[df['Area'].isna() & df['City'].str.contains(str(parent['c']).strip())]
    #df_tmp = df[df['Area'].isna()]
    # print(pd.DataFrame(df['City'] == str(parent['c']),df['Area'] == None))
    # print(str(parent['c']))
    # print('0000000000000000000000000000000000000')
    # print(df_tmp)
    # print(len(df_tmp))
    
    if len(df_tmp) == 0:
        #print(1)
        return seek_in_prov(df, parent['p'])

    
    if len(df_tmp) >= 1:
        #print()
        lsps = df_tmp['Fwd_Agent'].values
        rts = df_tmp['Shpt_Rt'].values

        return lsps, rts
        

# match province column        
def seek_in_prov(df, prov):
    
    df_tmp = df[df['Area'].isna() & 
                df['City'].isna() &
                df['Province'].str.contains(prov)]


    if len(df_tmp) > 0:
        lsps = df_tmp['Fwd_Agent'].values
        rts = df_tmp['Shpt_Rt'].values

        return lsps, rts
    
    if len(df_tmp) == 0:
        print(' no data')
        return [],[]
    

def tpp_cal(df_y, df_x):

    print('\tCalculation for tpp...')

    # import fact table for checking tpp
    tpp_cols = ['Shipment Number', 'Sales Organization', 'Plant', 'Storage Location']
    df_fac_tpp = df_y[tpp_cols].dropna(subset=['Storage Location'])
    tpp_cols.remove('Shipment Number')

    # import dim table of tpp
    df_dim_tpp = pd.read_excel(config_dim['sps']['file'],
                               sheet_name=config_dim['sps']['sheet']
                               ).dropna(how='all')

    # merge two table to get right tpp
    df_tpp_y = pd.merge(df_fac_tpp, df_dim_tpp, 
                        how='left',
                        left_on=tpp_cols,
                        right_on=list(df_dim_tpp.columns[:3]))
    df_tpp_y = df_tpp_y[['Shipment Number', 'TPP']].drop_duplicates()

    # check tpp_x against tpp_y
    if len(df_tpp_y) == len(df_tpp_y['Shipment Number'].unique()):

        df_tpp_x = df_x[['Shipment Number', 'TransportPlanningPt']]
        df_tpp_yx = pd.merge(df_tpp_y, df_tpp_x,
                             how='left', on='Shipment Number')
        df_tpp_yx.columns = ['shpt_num', 'tpp_y', 'tpp_x']

        global df_all
        df_all = df_tpp_yx


def type_cal(df_y, df_x):

    print('\tCalculation for type...')

    # import fact table for checking tpp
    type_cols = ['Shipment Number', 'Route']
    df_fac_type = df_y[type_cols]

    # create map for type
    type_map = {
        'W': 'YAW0',
        'T': 'YAT0',
        'R': 'YAR0'
    }
    # # map to get right type
    col_rt = df_fac_type['Route'].map(lambda x: type_map[x[0]], na_action='ignore')
    # col_rt = map(lambda x: type_map[x[0]],df_fac_type['Route'])
    df_fac_type.loc[:, 'Route'] = col_rt
    df_type_y = df_fac_type.drop_duplicates()

    # check type_x against type_y
    if len(df_type_y) == len(df_type_y['Shipment Number'].unique()):

        df_type_x = df_x[['Shipment Number', 'Shipment type']]
        df_type_yx = pd.merge(df_type_y, df_type_x,
                              how='left', on='Shipment Number')
        df_type_yx.columns = ['shpt_num', 'shpt_type_y', 'shpt_type_x']

        global df_all
        df_all = pd.merge(df_all, df_type_yx, how='left',
                          on='shpt_num') if len(df_all) > 0 else df_type_yx


def dg_cal(df):

    print('\tCalculation for dg...')

    # import fact table for dg
    dg_cols = ['Shipment Number', 'Contains DG']
    df_fac_dg = df[dg_cols].fillna(0)

    # replace map to get right type
    col_dg = df_fac_dg['Contains DG'].replace('X', 1)
    df_fac_dg.loc[:, 'Contains DG'] = col_dg
    df_dg_y = df_fac_dg.drop_duplicates()

    if len(df_dg_y) == len(df_dg_y['Shipment Number'].unique()):

        df_dg_y.columns = ['shpt_num', 'dg']

        global df_all
        df_all = pd.merge(df_all, df_dg_y, how='left',
                          on='shpt_num') if len(df_all) > 0 else df_dg_y


def lsp_rt_cal(df_y, df_x):

    print('\tCalculation for lsp & route...')

    global df_all
    # import fact table for checking lsp

    df_y = df_y[~df_y['Material'].str.startswith('6')]
    lsp_cols = ['Shipment Number', 'Description', 'SH-City']
    df_fac_lsp = df_y[lsp_cols].drop_duplicates()

    # map to get right group
    col_desc = df_fac_lsp['Description'].map(lambda x: '0013'
                                             if any(wd in x for wd in ['kg', 'KG'])
                                             else '0010',
                                             na_action='ignore')
    df_fac_lsp.loc[:, 'Description'] = col_desc
    df_fac_lsp.sort_values(by=['Description'], inplace=True)
    df_fac_lsp.drop_duplicates(subset=['Shipment Number'], inplace=True, keep='last')

    # # merge to get tpp, type, and dg
    df_fac_lsp = pd.merge(df_fac_lsp, df_all[['shpt_num', 'tpp_y', 'shpt_type_y', 'dg']],
                          how='left',
                          left_on=['Shipment Number'],
                          right_on=['shpt_num'])

    del df_fac_lsp['Shipment Number']

    #
    columns = ['shpt_num', 'Description', 'SH-City', 'tpp_y', 'shpt_type_y', 'dg']
    df_fac_lsp = df_fac_lsp[columns]
    df_fac_lsp.columns = ['shpt_num', 'shpt_grp', 'area', 'tpp', 'shpt_type', 'dg']
    lst_lsp, lst_rt = get_lsp_rt(df_fac_lsp)
    # return(df_fac_lsp)    


    # insert right lsp and rt columns
    df_fac_lsp.insert(df_fac_lsp.shape[1], 'lsp', lst_lsp)
    df_fac_lsp.insert(df_fac_lsp.shape[1], 'shpt_rt', lst_rt)
    df_lsp_y = df_fac_lsp[['shpt_num', 'lsp', 'shpt_rt', 'shpt_grp', 'area_cn']]
    # # check lsp_x & rt_x against lsp_y & rt_y
    if len(df_lsp_y) == len(df_lsp_y['shpt_num'].unique()):

        df_lsp_x = df_x[['Shipment Number', 'Service agent', 'Shipment route']]
        #print(df_lsp_y)
        df_lsp_yx = pd.merge(df_lsp_y, df_lsp_x, how='left',
                                                 left_on=['shpt_num'],
                                                 right_on=['Shipment Number'])
        del df_lsp_yx['Shipment Number']
        df_lsp_yx.columns = ['shpt_num', 'lsp_y', 'shpt_rt_y', 'shpt_grp', 'area_cn', 'lsp_x', 'shpt_rt_x']
        #print(df_lsp_yx)
        df_all = pd.merge(df_all, df_lsp_yx, how='left', on='shpt_num') if len(df_all) > 0 else df_lsp_yx


def pkg_cal(df_x):
    #print(df_all)
    print('\tCalculation for packing material...')

    global df_all

    # import fact table for checking packing
    
    pkg_cols = ['shpt_num', 'lsp_y', 'shpt_type_y', 'shpt_grp']
    df_fac_pkg = df_all[pkg_cols]
    pkg_cols.remove('shpt_num')

    # import dim table of packing
    df_dim_pkg = pd.read_excel(config_dim['pkg']['file'],
                               sheet_name=config_dim['pkg']['sheet'],
                               dtype={'Fwd_Agent': str,
                                      'Shpt_Grp': str,
                                      'Packing_Type': str}
                               ).dropna(how='all')
    pkg_dim_col = ['Fwd_Agent', 'Shpt_Type', 'Shpt_Grp']
    # print(df_fac_pkg)

    # # merge two table to get right tpp
    df_pkg_y = pd.merge(df_fac_pkg, df_dim_pkg, how='left',
                        left_on=pkg_cols,
                        right_on=pkg_dim_col)
    #print(df_pkg_y)
    df_pkg_y = df_pkg_y[['shpt_num', 'Packing_Type']].drop_duplicates()

    # check pkg_x against pkg_y
    if len(df_pkg_y) == len(df_pkg_y['shpt_num'].unique()):

        df_pkg_x = df_x[['Shipment Number', 'Means of transport']]
        df_pkg_x.sort_values(by=['Means of transport'], inplace=True)
        df_pkg_x.drop_duplicates(subset=['Shipment Number'], inplace=True, keep='first')

        df_pkg_yx = pd.merge(df_pkg_y, df_pkg_x,
                             how='left', 
                             left_on='shpt_num',
                             right_on='Shipment Number')
        del df_pkg_yx['Shipment Number']
        df_pkg_yx.columns = ['shpt_num', 'pkg_y', 'pkg_x']
        df_pkg_yx.fillna('NO_VALUE', inplace=True)
        
        df_all = pd.merge(df_all, df_pkg_yx, how='left', on='shpt_num') if len(df_all) > 0 else df_pkg_yx
        #print(df_all)

def pt_cal(df_y):
    print('\tCalculation for postal code & tfzone...')

    global df_all
    
    # import fact table for checking pcode
    pcode_cols = ['Shipment Number', 'SH-Postal Code', 'tzone']
    df_y = df_y[pcode_cols].sort_values(by=['SH-Postal Code'])
    df_y.drop_duplicates(subset=['Shipment Number'], inplace=True, keep='first')

    df_fac_pcode =  pd.merge(df_all[['shpt_num', 'tpp_y','area_cn']], 
                             df_y, how='left',
                             left_on='shpt_num',
                             right_on='Shipment Number')
    del df_fac_pcode['Shipment Number']

    # import dim table of tpp
    df_dim_pcode = pd.read_excel(config_dim['tfzone']['file'],
                                 sheet_name=config_dim['tfzone']['sheet'],
                                 usecols=config_dim['tfzone']['cols'],
                                 dtype={'PostalCode (from)': str,
                                        'PostalCode (to)': str}
                                 ).dropna(how='all')

    lst_p_from = []
    lst_p_to = []
    lst_tzone = []
    for row in df_fac_pcode.itertuples(index=True, name='Pandas'):

        p_from, p_to, tzone = '', '', ''

        # basic filter
        df_filter = df_dim_pcode[(df_dim_pcode['TPPt'] == row.tpp_y) &
                                  df_dim_pcode['DescriptionTo'].str.contains(row.area_cn)]
        df_filter = df_filter[df_filter['DescriptionTo'] == min(df_filter['DescriptionTo'].values, key=len)]

        if len(df_filter) == 0:
            print(' no data')

        if len(df_filter) >= 1:
            p_from = df_filter['PostalCode (from)'].values[0]
            p_to = df_filter['PostalCode (to)'].values[0]
            tzone = df_filter['TrfZn'].values[0]
        
        lst_p_from.append(p_from)
        lst_p_to.append(p_to)
        lst_tzone.append(tzone)
    
    # insert right lsp and rt columns
    df_fac_pcode.insert(df_fac_pcode.shape[1], 'p_from', lst_p_from)
    df_fac_pcode.insert(df_fac_pcode.shape[1], 'p_to', lst_p_to)
    df_fac_pcode.insert(df_fac_pcode.shape[1], 'tzone_y', lst_tzone)
    df_pcode_yx = df_fac_pcode[['shpt_num', 'SH-Postal Code', 'p_from', 'p_to', 'tzone_y', 'tzone']]
    df_pcode_yx.columns = ['shpt_num', 'p', 'p_from', 'p_to', 'tzone_y', 'tzone_x']

    df_all = pd.merge(df_all, df_pcode_yx, how='left', on='shpt_num') if len(df_all) > 0 else df_pcode_yx


def items_check():
    logging.info('\tCheck for all items calculated...')
    print('\tCheck for all items calculated...')

    global df_all

    dic_cond = {
        'TPP': df_all['tpp_y'] != df_all['tpp_x'],
        'Shipment Type': df_all['shpt_type_y'] != df_all['shpt_type_x'],
        'Vender': df_all['lsp_y'] != df_all['lsp_x'],
        'Route': df_all['shpt_rt_y'] != df_all['shpt_rt_x'],
        'Packing Material': df_all.apply(lambda x: x['pkg_x'] not in x['pkg_y'], axis=1),
        'Postal Code': (df_all['p'] < df_all['p_from']) | (df_all['p_to'] < df_all['p']),
        'Tariff Zone': df_all['tzone_y'] != df_all['tzone_x']
    }
    
    
    # generate reason table
    dic_rsn = {shpt_num: ['Other'] for shpt_num in df_all['shpt_num'].tolist()}
    for rsn in dic_cond:

        # get all shipments for each reason 
        for shpt in df_all[dic_cond[rsn]]['shpt_num'].tolist():
            if dic_rsn[shpt] == ['Other']:
                dic_rsn[shpt].remove('Other')
            dic_rsn[shpt].append(rsn)

    df_rsn = pd.DataFrame(dict([(k, pd.Series(v)) for k, v in dic_rsn.items()])).T.reset_index()
    #print(df_rsn)
    # output the result and reason
    with pd.ExcelWriter(config_output['dat']['file']) as writer:
        
        df_dat = df_all[config_output['dat']['cols']].sort_values(by=['shpt_num'])
        df_dat.to_excel(writer, sheet_name=config_output['dat']['sheet'], index=False)
        
        rsn_cols = ['shpt_num']
        rsn_cols.extend(['R{}'.format(i) for i in range(1, df_rsn.shape[1])])
        df_rsn.columns = rsn_cols
        df_rsn.to_excel(writer, sheet_name=config_output['rsn']['sheet'], index=False)


if __name__ == '__main__':

    # calculate run time
    start = time()

    # load config for fact tables
    with open (FACT_CONFIG, 'rb') as f:
        config_fac = json.loads(f.read())
    
    # load config for dim tables
    with open (DIM_CONFIG, 'rb') as f:
        config_dim = json.loads(f.read())
    
    # load config for output table
    with open (OUTPUT_CONFIG, 'rb') as f:
        config_output = json.loads(f.read())
    
    print('Configuration for fac, dim, output loaded...')


    # get a list of shipment number where diff is greater than a given threshold
    df_rets = [pd.read_excel(config_fac['ret']['folder'] + ret, dtype={'Shipment Number': str})
                    for ret in listdir(config_fac['ret']['folder']) if ret.endswith('.xlsx')]
    df_ret = pd.concat(df_rets)[config_fac['ret']['cols']].dropna(how='all').drop_duplicates()

    lst_shpt_num = shpt_filter(df_ret, DIFF_THRESHOLD)


    # get a list of shipment number where val in system is 0
    df_0 = pd.read_excel(config_fac['zero']['file'],
                         sheet_name=config_fac['zero']['sheet'],
                         usecols=config_fac['zero']['cols'],
                         dtype={'Shipment Number': str},
                         squeeze=True).dropna(how='all')
    lst_shpt_num_0 = df_0.tolist()
    lst_shpt_num.extend(lst_shpt_num_0)
    lst_shpt_num = list(set(lst_shpt_num))

    

    # get sub table of delivery based on shpt_num
    df_dlv = pd.read_excel(config_fac['dlv']['file'],
                           sheet_name=config_fac['dlv']['sheet'],
                           usecols=config_fac['dlv']['cols'],
                           dtype={'Shipment Number': str,
                                  'SH-Postal Code': str,
                                  'Material': str,
                                  'Means of transport': str}
                           ).dropna(how='all')
    df_dlv = df_dlv[df_dlv['Shipment Number'].isin(lst_shpt_num)]


    # get sub table of shipment based on shpt_num
    df_shpt = pd.read_excel(config_fac['shpt']['file'],
                            sheet_name=config_fac['shpt']['sheet'],
                            usecols=config_fac['shpt']['cols'],
                            dtype={'Shipment Number': str,
                                   'Service agent': str}
                            ).dropna(how='all')
    df_shpt = df_shpt[df_shpt['Shipment Number'].isin(lst_shpt_num)]
    shpt_vld(lst_shpt_num, df_dlv['Shipment Number'])

    # # calculate all itmes    
    tpp_cal(df_dlv, df_shpt)
    type_cal(df_dlv, df_shpt)
    dg_cal(df_shpt)
    lsp_rt_cal(df_dlv, df_shpt)
    pkg_cal(df_dlv)
    pt_cal(df_dlv)
    items_check()

    print('\nTask Completed with {:.2f}s!'.format(time() - start))