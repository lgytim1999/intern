from os import system, getcwd
import pandas as pd
import win32com.client as win32
from ctypes import windll
from subprocess import Popen
from time import sleep

###################################################
########**PREPARISON for fixing process**##########
###################################################

# load the "result.xlsx" file here
# /process_of_check/output
def load_result_xlsx():
    current_dir = getcwd()
    result_dir = current_dir +r"\process_of_check\output\result.xlsx"
    result_data = pd.read_excel(result_dir, sheet_name="data")
    result_reason = pd.read_excel(result_dir, sheet_name="reason")
    return result_data,result_reason


# get username and password if necessary
# in user_info.txt 
def get_user_info():
    with open(getcwd()+r"\fix_in_sap\user_info.txt") as f:
        user, passw = f.readlines()
        username = user.split(r"\n")[0].strip()
        password = passw.strip()
        return username, password


# log on SAP 
# no matter if user_info has been provided
def log_on_sap():
    try:
        response = windll.user32.MessageBoxW(0, "Make sure all the data have been saved before shutting down SAP", "Warning", 1) 
    except Exception:
        print("SAP hasn't been run yet...")   
    if response == 1:
        # shut down existing sap process
        system('taskkill /F /im saplogon.exe')
        # reopen sap
        p_sap = Popen("C:/Program Files (x86)/SAP/FrontEnd/SAPgui/saplogon.exe")
        sleep(1)
    # choose the database and log in
    sap_gui = win32.GetObject('SAPGUI')
    sap_app = sap_gui.GetScriptingEngine
    sap_con = sap_app.openconnection("Cobalt - Z2L (Prod)")
    session = sap_con.Children(0)
    session.findById("wnd[0]").maximize
    
    try:
        # log in sap with username and password
        session.findById("wnd[0]/usr/txtRSYST-BNAME").text, session.findById("wnd[0]/usr/pwdRSYST-BCODE").text = get_user_info()
        session.findById("wnd[0]").sendVKey(0)

    except Exception as e:
        # no usr & pwd provided
        session.findById("wnd[0]").sendVKey(0)
        print("No user info needed for logging on SAP...")
    return session


###################################################
########**functions to fix the problems**##########
###################################################

# adapt route for shipment record having problem in SAP 
def adapt_route(shipment_number):
    return 0


###################################################
##############**fix these problems**###############
###################################################


# figure out which problem the shipment order has and fix it in SAP
# total 7 problems for now
# 'TPP': 
# 'Shipment Type': 
# 'Vender': 
# 'Route': 
# 'Postal Code'
# 'Packing Material':
# 'Tariff Zone': 

def fix_problem(row):
    shipment_number = row[0]
    for problem in row[1:]:
        if problem == "Route":
            adapt_route(shipment_number)
        elif problem == "TPP":
            adapt_tpp(shipment_number)
        elif problem == "Shipment Type":
            adapt_shipment_type(shipment_number)
        elif problem == "Vender":
            adapt_vender(shipment_number)
        elif problem == "Postal Code":
            adapt_postal_code(shipment_number)
        elif problem == "Packing Material":
            adapt_packing_material(shipment_number)
        elif problem == "Tariff Zone":
            adapt_tariff_zone(shipment_number)

    


if __name__ == "__main__":
    result_data, result_reason = load_result_xlsx()
    session = log_on_sap()

