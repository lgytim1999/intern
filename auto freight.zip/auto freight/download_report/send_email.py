# -*- coding: utf-8 -*-
from pickle import encode_long
from openpyxl import load_workbook
import os
import win32com.client as win32
import pandas as pd
import numpy as np

df_eda_creater  = pd.read_excel(os.getcwd()+r'\download_report\config\EDA creater.xlsx')
output_file_list = os.listdir(os.getcwd()+r"\download_report\output")
for file_name in output_file_list:
    df_output_file = pd.read_excel(os.getcwd()+r"\download_report\output" + r'\ '.strip() + file_name)
    column_name=df_output_file.columns.tolist()
    column_name.insert(6, 'company')
    column_name.insert(8, 'department')
    df_output_file=df_output_file.reindex(columns=column_name) 

    for index1, row in df_output_file.iterrows():
        for index2, row_eda in df_eda_creater.iterrows(): 
            if row.tolist()[5] == row_eda.tolist()[7]:
                df_output_file.loc[index1,'company'] = row_eda.tolist()[8]

            if row.tolist()[7] == row_eda.tolist()[3]:
                df_output_file.loc[index1,'department'] = row_eda.tolist()[4]
    df_output_file = df_output_file.dropna(subset=['department'])
    for party in list(set(df_output_file['Invocing party'].tolist())):
        df_output_file1 = df_output_file[df_output_file['Invocing party'] == party]
        pt = pd.pivot_table(df_output_file1, index=['company','Description','Shipment Number'],  values=['Gross weight','Net value'], aggfunc={'Net value':np.sum,'Gross weight':np.sum}, margins=True) # = ['department','Invoicing party'] ,
        pt.to_excel(os.getcwd()+r"\download_report\output" + r'\ '.strip() + str(party)+'.xlsx')
        
        #该单元格大小
        wb = load_workbook(os.getcwd()+r"\download_report\output" + r'\ '.strip() + str(party)+'.xlsx')
        ws = wb[wb.sheetnames[0]]
        
        # 调整列宽
        ws.column_dimensions['A'].width = 20.0 
        ws.column_dimensions['B'].width = 20.0
        ws.column_dimensions['C'].width = 20.0
        ws.column_dimensions['D'].width = 20.0
        ws.column_dimensions['E'].width = 20.0
        wb.save(os.getcwd()+r"\download_report\output" + r'\ '.strip() + str(party)+'.xlsx')





# #发邮件部分
# workbook = load_workbook(filename =os.getcwd()+r"\download_report\config\config.xlsx")
# sheet = workbook.active

# # 读取表格，获取行数
# num = 1
# while 1:
#     cell = sheet.cell(row=num, column=2).value
#     if cell:
#         cell1 = sheet.cell(row=num, column=2)
#         cell2 = sheet.cell(row=num, column=3)

#         num = num + 1
#     else:
#         break
# ###读取文件，获得名称
# os.chdir(os.getcwd()+r"\download_report\output")
# file_list=os.listdir('.')

# def send_mail_via_com():
#     outlook =  win32.Dispatch("Outlook.Application")
#     mail = outlook.CreateItem(0)
#     mail.To =emailSendTo

#     mail.Subject = emailTitle
#     mail.HTMLBody = content
#     mail.Attachments.Add(attachment)

#     mail.Save()
# ########
# for file in file_list:
#     for i in range(num):
#         cell1 = sheet.cell(row=i+1, column=2)
#         cell2 = sheet.cell(row=i+1, column=3)
#         cell3 = sheet.cell(row=i+1, column=4)

#         if str(os.path.splitext(file)[0]).strip() == str(cell1.value).strip():
#             emailTitle = "Subject"
#             content = "1111"
#             emailSendTo = cell2.value
#             os.rename(os.getcwd()+r'\ '.strip()+file,os.getcwd()+r'\ '.strip()+str(cell3.value)+'.xlsx')
#             file1 = os.getcwd()+r'\ '.strip() + cell3.value+'.xlsx' 
#             attachment = file1 # 文件地址
#             send_mail_via_com()
