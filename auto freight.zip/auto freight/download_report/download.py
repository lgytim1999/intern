# -*- coding: utf-8 -*-
from os import system, getcwd,listdir
import pandas as pd
import win32com.client as win32
from ctypes import windll
from subprocess import Popen
from time import sleep
from datetime import date
import pandas as pd

###################################################
########**PREPARISON for fixing process**##########
###################################################

# get username and password if necessary
# in user_info.txt 
def get_user_info():
    with open(getcwd()+r"\download_report\user_info.txt") as f:
        user, passw = f.readlines()
        username = user.split(r"\n")[0].strip()
        password = passw.strip()
        return username, password
#get date today
def today_date():
    today = date.today().strftime('%d.%m.%Y')
    return today

def day(today):
    if len(str(int(today[3:5])-1)) == 1:
        settlement_start_date = '01.0'+str(int(today[3:5])-1)+today[5:]
    else:
        settlement_start_date = '01.'+str(int(today[3:5])-1)+today[5:]

    if len(str(int(today[3:5])-1)) == 1:
        settlement_end_date = '30.0'+str(int(today[3:5])-1)+today[5:]
    else:
        settlement_end_date = '30.'+str(int(today[3:5])-1)+today[5:]
    
    #Completion date
    completion_start_date = '01.01.' + str(int(today[6:10])-1)
    if len(str(int(today[3:5])-1)) == 1:
        completion_end_date = '30.0'+str(int(today[3:5])-1)+today[5:]
    else:
        completion_end_date = '30.'+str(int(today[3:5])-1)+today[5:]
    
    return settlement_start_date, settlement_end_date, completion_start_date, completion_end_date
    
#read config file
#modify the infomation in config.xlsx when needed
#session,tcode,lsp_code,current_date,file_name
def config():
    df_config = pd.read_excel(getcwd()+r'\download_report\config\config.xlsx')
    return df_config.fillna(value='')
        

# log on SAP 
# no matter if user_info has been provided
def log_on_sap():
    try:
        response = windll.user32.MessageBoxW(0, "Make sure all the data have been saved before shutting down SAP", "Warning", 1) 
    except Exception:
        print("SAP hasn't been run yet...")   
    if response == 1:
        # shut down existing sap process
        system('taskkill /F /im saplogon.exe')
        # reopen sap
        p_sap = Popen("C:/Program Files (x86)/SAP/FrontEnd/SAPgui/saplogon.exe")
        sleep(1)
    # choose the database and log in
    sap_gui = win32.GetObject('SAPGUI')
    sap_app = sap_gui.GetScriptingEngine
    sap_con = sap_app.openconnection("Cobalt - Z2L (Prod)")
    session = sap_con.Children(0)
    session.findById("wnd[0]").maximize
    
    try:
        # log in sap with username and password
        # session.findById("wnd[0]/usr/txtRSYST-BNAME").text, session.findById("wnd[0]/usr/pwdRSYST-BCODE").text = get_user_info()
        usr, pswd = get_user_info()
        session.findById("wnd[0]/usr/txtRSYST-BNAME").text = usr
        session.findById("wnd[0]/usr/pwdRSYST-BCODE").text = pswd
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]").resizeWorkingPane(112, 37, 0)

    except Exception as e:
        # no usr & pwd provided
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[0]").resizeWorkingPane(112, 37, 0)
        print("No user info needed for logging on SAP...")
    return session


def download(session,tcode,lsp_code,current_date,file_name):
    settlement_start_date, settlement_end_date, completion_start_date, completion_end_date = day(current_date)
    session.findById("wnd[0]/tbar[0]/okcd").text = tcode #"ZCN_TM_FREIGHT"
    session.findById("wnd[0]").sendVKey(0)
    session.findById("wnd[0]/mbar/menu[2]/menu[0]/menu[0]").select(),
    session.findById("wnd[1]/usr/txtV-LOW").text = "EDA"
    session.findById("wnd[1]/usr/txtENAME-LOW").text = ""
    session.findById("wnd[1]/usr/txtENAME-LOW").setFocus()
    session.findById("wnd[1]/usr/txtENAME-LOW").caretPosition = 0
    session.findById("wnd[1]/tbar[0]/btn[8]").press()
    session.findById("wnd[0]/usr/ctxtV_MAINSP-LOW").text = lsp_code #"1983814"
    session.findById("wnd[0]/usr/ctxtV_DTABF-LOW").text = completion_start_date # 01.01.2020
    session.findById("wnd[0]/usr/ctxtV_DTABF-HIGH").text = completion_end_date #"30.04.2021"
    session.findById("wnd[0]/usr/ctxtV_BUDAT-LOW").text = settlement_start_date
    session.findById("wnd[0]/usr/ctxtV_BUDAT-HIGH").text = settlement_end_date
    session.findById("wnd[0]/usr/ctxtV_BUDAT-HIGH").setFocus()
    session.findById("wnd[0]/usr/ctxtV_BUDAT-HIGH").caretPosition = 10
    session.findById("wnd[0]/tbar[1]/btn[8]").press()
    session.findById("wnd[0]/mbar/menu[0]/menu[1]/menu[1]").select()
    session.findById("wnd[1]/usr/ctxtDY_PATH").text = getcwd()+ r'\download_report\output'
    session.findById("wnd[1]/usr/ctxtDY_PATH").caretPosition = 59
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").text = file_name #"1983814.xlsx"
    session.findById("wnd[1]/usr/ctxtDY_FILENAME").caretPosition = 12
    session.findById("wnd[1]/tbar[0]/btn[0]").press()
    session.findById("wnd[0]/tbar[0]/btn[15]").press()
    session.findById("wnd[0]/tbar[0]/btn[15]").press()

# shut down all the open excel workbooks
# at last
def kill_excel(folder:str, file: str):
    try:            
        excel = win32.GetObject(folder + '\\' + file).Application
        excel.Workbooks(file).Close()
        print('Kill file: {}'.format(folder + '\\' + file))
    except:                
        pass

#clear all the files in output
# make sure it is empty when running this program
def clear_folder(folders: list):
    for folder in folders:
        for file in listdir(folder):
            kill_excel(folder, file)
        system('del /f /q "{}"\*'.format(folder)) 

# main
def main():
    clear_folder([getcwd()+ r'\download_report\output'])
    session = log_on_sap()
    df = config()
    for index, row in df.iterrows():
        if row[0] != '':
            tcode = str(row[0])
            lsp_code = str(row[1])
            file_name = str(lsp_code) + '.xlsx'
            current_date = today_date()
            download(session,tcode,lsp_code,current_date,file_name)
    sleep(4)
    [kill_excel(getcwd()+ r'\download_report\output', file) for file in listdir(getcwd()+ r'\download_report\output')]
if __name__ == '__main__':
    main()